
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open('dmw-cache-v1').then(cache => cache.addAll([
      '/index.html','/contact.html','/updates.html','/subscription.html','/announcements.html','/styles.css','/app.js','/manifest.json'
    ]))
  );
});
self.addEventListener('fetch', event => {
  event.respondWith(caches.match(event.request).then(resp => resp || fetch(event.request)));
});
