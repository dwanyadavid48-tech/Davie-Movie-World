
// Basic interactivity and animations
document.addEventListener('DOMContentLoaded', () => {
  // remove loading after ready
  const loader = document.getElementById('loading-screen');
  setTimeout(()=>{ if(loader){ loader.style.opacity='0'; loader.style.transition='0.8s'; setTimeout(()=>loader.remove(),900);} }, 900);

  // poster hover tilt
  document.querySelectorAll('.poster').forEach(p => {
    p.addEventListener('pointermove', (ev)=>{
      const r = p.getBoundingClientRect();
      const px = (ev.clientX - r.left) / r.width - 0.5;
      const py = (ev.clientY - r.top) / r.height - 0.5;
      p.style.transform = `rotateY(${px*12}deg) rotateX(${py*-8}deg) scale(1.03)`;
    });
    p.addEventListener('pointerleave', ()=> p.style.transform = 'rotateY(0deg) rotateX(0deg) scale(1)');
  });

  // simple newsletter demo
  const form = document.querySelector('.newsletter form');
  if(form) form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const email = form.querySelector('input[type=email]').value;
    alert('Demo: ' + email + ' subscribed. Replace this with your mailing provider integration.');
    form.reset();
  });
});
