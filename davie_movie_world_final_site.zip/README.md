# Davie Movie World — Static PWA Site

This folder contains a static, PWA-ready website for Davie Movie World.

**Files:** index.html, contact.html, updates.html, subscription.html, announcements.html, styles.css, app.js, manifest.json, sw.js, icons/

**To publish (GitHub Pages):**
1. Create a new GitHub repository.
2. Upload all files (root of repo).
3. In repository **Settings → Pages**, select **main branch / root** and Save.
4. The site will be published at `https://<yourusername>.github.io/<repo>/`.

**Notes:**
- Replace demo forms with your Mailchimp / SendGrid / Stripe integrations for production.
- Update icons in `/icons` with branded art.
- Service worker provided is a minimal cache-first implementation.
